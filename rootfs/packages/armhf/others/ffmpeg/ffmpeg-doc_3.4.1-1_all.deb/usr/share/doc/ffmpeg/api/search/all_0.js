var searchData=
[
  ['_5fwin32_5fwinnt',['_WIN32_WINNT',['../d3d11va_8h.html#ac50762666aa00bd3a4308158510f1748',1,'_WIN32_WINNT():&#160;d3d11va.h'],['../dxva2_8h.html#ac50762666aa00bd3a4308158510f1748',1,'_WIN32_WINNT():&#160;dxva2.h']]],
  ['_5fxopen_5fsource',['_XOPEN_SOURCE',['../filtering__video_8c.html#a78c99ffd76a7bb3c8c74db76207e9ab4',1,'filtering_video.c']]]
];
